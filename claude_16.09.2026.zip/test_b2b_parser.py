"""Проверки нормализации B2B-Center на сохранённой реальной выдаче."""

from __future__ import annotations

from pathlib import Path
import unittest

from src.collectors.b2b_center import B2BCenterCollector
from src.models.tender import Tender


class B2BCenterCollectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.collector = B2BCenterCollector({"request_delay_seconds": 0})
        html = Path("b2b_test.html").read_text(encoding="utf-8")
        cls.results = cls.collector._parse_search_html(
            html,
            "подшипники",
        )

    def test_import_and_platform_identifier(self) -> None:
        self.assertEqual(self.collector.platform, "b2b_center")

    def test_search_result_is_normalized_tender(self) -> None:
        self.assertGreaterEqual(len(self.results), 1)
        self.assertTrue(all(isinstance(item, Tender) for item in self.results))

    def test_result_has_identifier_title_url_and_dates(self) -> None:
        tender = self.results[0]

        self.assertTrue(tender.external_id.isdigit())
        self.assertTrue(tender.title)
        self.assertFalse(
            tender.title.lower().startswith(
                ("тендер", "запрос предложений", "аукцион", "конкурс")
            )
        )
        self.assertTrue(tender.url.startswith("https://www.b2b-center.ru/"))
        self.assertIn(f"tender-{tender.external_id}", tender.url)
        self.assertIsNotNone(tender.published_at)
        self.assertIsNotNone(tender.deadline)
        self.assertIsNotNone(tender.published_at.tzinfo)
        self.assertIsNotNone(tender.deadline.tzinfo)

    def test_price_and_commercial_condition_extractors(self) -> None:
        self.assertEqual(
            self.collector._extract_price("Общая стоимость закупки: 12 345,67 руб."),
            12345.67,
        )

        conditions = self.collector._extract_commercial_conditions(
            "Условия оплаты: 100% по факту поставки в течении "
            "30 календарных дней."
        )
        self.assertFalse(conditions["advance_required"])
        self.assertEqual(conditions["postpayment_days"], 30)

    def test_keyword_relevance_covers_required_smoke_keywords(self) -> None:
        """Regression: `_keyword_matches_tender` must not silently drop real
        matches for any of the three mandated smoke-test keywords, and must
        accept them regardless of which word form is used as the query.

        This previously dropped every подшипник/лебедка result outright
        (missing from the variant table) and dropped станок/подшипник/лебедка
        results whenever the query itself used a declined word form, because
        the variant lookup was keyed only by the exact nominative singular.
        """
        cases = [
            ("станок", "Поставка станка токарного"),
            ("станки", "Поставка станка токарного"),
            ("подшипник", "Поставка подшипников качения"),
            ("подшипники", "Поставка подшипников качения"),
            ("лебедка", "Закупка лебедки монтажной"),
            ("лебедки", "Закупка лебедки монтажной"),
        ]
        for keyword, title in cases:
            tender = Tender(
                external_id="1",
                platform="b2b_center",
                title=title,
                url="https://www.b2b-center.ru/market/tender-1-1/",
                published_at=None,
                deadline=None,
            )
            with self.subTest(keyword=keyword):
                self.assertTrue(
                    self.collector._keyword_matches_tender(tender, keyword),
                    f"expected {keyword!r} to match title {title!r}",
                )

    def test_title_cleanup_removes_service_prefix(self) -> None:
        self.assertEqual(
            self.collector._clean_procedure_title(
                "Запрос предложений № 4571794 — Поставка подшипников",
                "4571794",
            ),
            "Поставка подшипников",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
