"""Resilient browser search helpers for JS-heavy public tender portals."""
from __future__ import annotations

import logging
import re

from bs4 import BeautifulSoup

from src.collectors.base import CollectorUnavailableError
from src.collectors.browser_public import RtsTenderCollector, TmkCollector
from src.collectors.rosatom import RosatomCollector
from src.models.tender import Tender

logger = logging.getLogger(__name__)


class ReliableBrowserSearchMixin:
    """Search helper that tolerates delayed widgets, frames and pagination."""

    @staticmethod
    def _wait_for_initial_dom(page) -> None:
        """Do not make SPA search depend on every document resource finishing."""
        try:
            page.wait_for_load_state("domcontentloaded", timeout=10000)
        except Exception:
            pass
        try:
            page.locator("body").wait_for(state="attached", timeout=5000)
        except Exception:
            pass

    def _goto(self, page, url: str) -> None:
        """Navigate without waiting for long-lived XHR/WebSocket requests."""
        page.goto(url, wait_until="commit", timeout=self.timeout_ms)
        self._wait_for_initial_dom(page)

    def _search_one(self, query: str):
        logger.info("%s: поиск по ключевому слову: %s", self.platform, query)
        search_control_found = False
        html = ""
        try:
            from playwright.sync_api import sync_playwright

            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=True)
                context = browser.new_context(
                    locale="ru-RU",
                    viewport={"width": 1440, "height": 1000},
                    user_agent=(
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/151.0.0.0 Safari/537.36"
                    ),
                )
                page = context.new_page()
                self._goto(page, self.BASE_URL)
                page.wait_for_timeout(6500)
                self._dismiss_consent(page)

                search_control_found = self._perform_search(page, query)
                if not search_control_found:
                    if getattr(self, "ALLOW_PUBLISHED_LISTING_FALLBACK", False):
                        html = self._collect_rendered_html(page)
                        logger.warning(
                            "%s: SEARCH_ADAPTER_UNAVAILABLE — using published-listing fallback for %r",
                            self.platform, query,
                        )
                        browser.close()
                        results = self._parse_results(html)
                        logger.info(
                            "%s: published-listing fallback returned %d procedures",
                            self.platform,
                            len(results),
                        )
                        return results[: self.max_results]
                    self._log_page_state(page)
                    browser.close()
                    raise CollectorUnavailableError(
                        f"{self.platform}: search control unavailable for {query!r}"
                    )

                page.wait_for_timeout(4500)
                try:
                    page.wait_for_load_state("networkidle", timeout=9000)
                except Exception:
                    pass

                self._expand_results(page)
                html = self._collect_rendered_html(page)
                browser.close()
        except CollectorUnavailableError:
            raise
        except Exception as exc:
            logger.warning("%s: browser search failed for %r: %s", self.platform, query, exc)
            raise CollectorUnavailableError(
                f"{self.platform}: browser search failed for {query!r}: {type(exc).__name__}: {exc}"
            ) from exc

        parsed_results = self._parse_results(html)
        results = [tender for tender in parsed_results if self._tender_matches_query(tender, query)]
        if search_control_found and not parsed_results:
            logger.warning(
                "%s: RESULT_PARSER_ZERO — submitted search produced no parsed procedures for %r",
                self.platform,
                query,
            )
        if parsed_results and not results:
            logger.error(
                "%s: RESULT_QUERY_MISMATCH — parser returned %d procedures but none contain query %r; rejecting unverified results",
                self.platform,
                len(parsed_results),
                query,
            )
        logger.info(
            "%s: keyword=%r: search_control=%s, parsed=%d, matched=%d",
            self.platform,
            query,
            search_control_found,
            len(parsed_results),
            len(results),
        )
        return results

    @classmethod
    def _tender_matches_query(cls, tender: Tender, query: str) -> bool:
        """Reject false positives when a portal returns an unfiltered/global listing."""
        normalized_query = cls._normalize_search_text(query)
        if not normalized_query:
            return False
        haystack = cls._normalize_search_text(
            " ".join(
                (
                    tender.title or "",
                    tender.description or "",
                    str((tender.raw_data or {}).get("subject") or ""),
                )
            )
        )
        if normalized_query in haystack:
            return True
        variants = {
            "станок": ("станок", "станка", "станки", "станков", "станкам", "станками", "станке", "станком"),
            "подшипник": ("подшипник", "подшипника", "подшипники", "подшипников", "подшипнику", "подшипникам", "подшипником", "подшипниками", "подшипнике", "подшипниках"),
            "лебедка": ("лебедка", "лебедки", "лебедку", "лебедкой", "лебедкою", "лебедок", "лебедкам", "лебедками"),
            "редуктор": ("редуктор", "редуктора", "редукторы", "редукторов", "редукторам", "редукторами", "редукторе", "редуктором"),
        }
        # Resolve the query to its canonical (nominative singular) key
        # regardless of which declined form was searched for. A plain
        # dict.get(normalized_query, ()) only worked when the query itself
        # was already in nominative singular; any other form (plural,
        # genitive, etc.) silently matched nothing even when the tender
        # text plainly used a different form of the same word.
        query_variants = variants.get(normalized_query)
        if query_variants is None:
            for forms in variants.values():
                if normalized_query in forms:
                    query_variants = forms
                    break
        return any(re.search(rf"(?<![а-яёa-z0-9]){re.escape(variant)}(?![а-яёa-z0-9])", haystack) for variant in (query_variants or ()))

    @staticmethod
    def _normalize_search_text(value: str) -> str:
        return re.sub(r"[^0-9a-zа-я]+", " ", str(value or "").casefold().replace("ё", "е")).strip()

    def _parse_detail(self, html: str, external_id: str, url: str):
        """Run the platform parser, then recover common labels missed by HTML layout."""
        tender = super()._parse_detail(html, external_id, url)
        soup = BeautifulSoup(html or "", "html.parser")
        text = " ".join(soup.stripped_strings)

        if not tender.region:
            region_patterns = (
                r"(?:Регион поставки|Регион заказчика|Место поставки|Место выполнения|Регион)\s*[:\-]\s*(.+?)(?=\s+(?:Закон|Федеральный закон|НМЦ|Цена|Дата|Срок|Аванс|Оплата|Обеспечение)\b|$)",
                r"(?:Регион поставки|Место поставки)\s+(.+?)(?=\s+(?:Закон|НМЦ|Цена|Дата|Срок|Аванс|Оплата|Обеспечение)\b|$)",
            )
            for pattern in region_patterns:
                match = re.search(pattern, text, re.I)
                if match:
                    candidate = re.sub(r"\s+", " ", match.group(1)).strip(" ;,\t")
                    if candidate and len(candidate) <= 500:
                        tender.region = candidate
                        break

        if not tender.customer:
            match = re.search(
                r"(?:Заказчик|Организатор|Организация-заказчик)\s*[:\-]\s*(.+?)(?=\s+(?:Регион|Место|Закон|Дата|НМЦ|Цена|Срок|Аванс|Оплата|Обеспечение)\b|$)",
                text,
                re.I,
            )
            if match:
                tender.customer = re.sub(r"\s+", " ", match.group(1)).strip(" ;,")[:1000]

        if not tender.customer_inn:
            inn_patterns = (
                r"(?:ИНН|И\.Н\.Н\.)\s*[:№]?\s*(\d(?:\s*\d){9}(?:\s*\d\s*\d)?)\b",
                r"\bИНН\s*(\d(?:\s*\d){9}(?:\s*\d\s*\d)?)\b",
            )
            for pattern in inn_patterns:
                match = re.search(pattern, text, re.I)
                if match:
                    candidate = re.sub(r"\s+", "", match.group(1))
                    if len(candidate) in (10, 12):
                        tender.customer_inn = candidate
                        break

        if not tender.law_type:
            match = re.search(r"\b(44\s*-?\s*ФЗ|223\s*-?\s*ФЗ)\b", text, re.I)
            if match:
                normalized = re.sub(r"\s+", "", match.group(1)).replace("-", "-").upper()
                tender.law_type = "44-ФЗ" if normalized.startswith("44") else "223-ФЗ"

        return tender

    @staticmethod
    def _log_page_state(page) -> None:
        try:
            title = page.title()
        except Exception:
            title = ""
        try:
            url = page.url
        except Exception:
            url = ""
        try:
            body = " ".join(page.locator("body").inner_text(timeout=1500).split())[:600]
        except Exception:
            body = ""
        logger.warning("browser state: url=%s title=%r body=%r", url, title, body)

    @staticmethod
    def _dismiss_consent(page) -> None:
        labels = ("Принять", "Согласен", "Разрешить", "Закрыть", "Понятно", "Accept", "I agree")
        for label in labels:
            try:
                loc = page.get_by_role("button", name=label, exact=False)
                for idx in range(min(loc.count(), 3)):
                    item = loc.nth(idx)
                    if item.is_visible():
                        item.click(timeout=1200)
                        page.wait_for_timeout(300)
            except Exception:
                continue

    def _perform_search(self, page, query: str) -> bool:
        """Find and submit a search control, including SPA widgets and late-mounted forms."""
        selectors = (
            "input[type='search']", "input[role='searchbox']", "input[role='textbox']",
            "input[name*='search' i]", "input[name*='query' i]", "input[name*='keyword' i]",
            "input[name*='phrase' i]", "input[name*='text' i]", "input[placeholder*='поиск' i]",
            "input[placeholder*='закуп' i]", "input[placeholder*='наимен' i]",
            "input[placeholder*='ключев' i]", "input[placeholder*='слово' i]",
            "input[placeholder*='найти' i]", "input[aria-label*='поиск' i]",
            "input[aria-label*='закуп' i]", "input[aria-label*='найти' i]",
            "textarea[placeholder*='поиск' i]", "[role='searchbox']", "[contenteditable='true']",
            "[data-testid*='search' i] input", "[data-test*='search' i] input", "[class*='search' i] input",
        )
        search_labels = ("Найти закупку", "Поиск закупок", "Поиск", "Искать", "Найти", "Найти процедуры", "Искать закупки", "Показать результаты", "Показать", "Применить", "Применить фильтры", "Отправить", "Search", "Find")
        trigger_selectors = (
            "button[aria-label*='поиск' i]", "button[title*='поиск' i]", "button[data-testid*='search' i]",
            "button[data-test*='search' i]", "[role='button'][aria-label*='поиск' i]", "[role='button'][title*='поиск' i]",
            "[role='button'][data-testid*='search' i]", "[role='button'][data-test*='search' i]",
            "button[aria-label*='найти' i]", "button[title*='найти' i]", "[role='button'][aria-label*='найти' i]",
        )

        frames = [page.main_frame] + [frame for frame in page.frames if frame != page.main_frame]
        for frame in frames:
            for selector in trigger_selectors:
                try:
                    loc = frame.locator(selector).first
                    if loc.count() and loc.is_visible():
                        loc.click(timeout=1800)
                        page.wait_for_timeout(700)
                except Exception:
                    continue
            for label in search_labels:
                try:
                    loc = frame.get_by_role("button", name=label, exact=False).first
                    if loc.count() and loc.is_visible():
                        loc.click(timeout=1800)
                        page.wait_for_timeout(700)
                except Exception:
                    continue

        for frame in frames:
            for selector in selectors:
                try:
                    loc = frame.locator(selector).first
                    if not loc.count() or not loc.is_visible():
                        continue
                    loc.fill(query)
                    submitted = False
                    for label in search_labels:
                        try:
                            button = frame.get_by_role("button", name=label, exact=False).first
                            if button.count() and button.is_visible():
                                button.click(timeout=1800)
                                submitted = True
                                break
                        except Exception:
                            continue
                    if not submitted:
                        for selector_button in ("button[type='submit']", "input[type='submit']", "form button"):
                            try:
                                button = frame.locator(selector_button).last
                                if button.count() and button.is_visible():
                                    button.click(timeout=1800)
                                    submitted = True
                                    break
                            except Exception:
                                continue
                    if not submitted:
                        try:
                            loc.press("Enter")
                            submitted = True
                        except Exception:
                            pass
                    if submitted:
                        logger.info("%s: SEARCH_SUBMITTED selector=%s frame=%s", self.platform, selector, frame.url)
                        return True
                except Exception:
                    continue
            try:
                textbox = frame.get_by_role("textbox").first
                if textbox.count() and textbox.is_visible():
                    textbox.fill(query)
                    for label in search_labels:
                        try:
                            button = frame.get_by_role("button", name=label, exact=False).first
                            if button.count() and button.is_visible():
                                button.click(timeout=1800)
                                logger.info("%s: SEARCH_SUBMITTED selector=role=textbox frame=%s button=%s", self.platform, frame.url, label)
                                return True
                        except Exception:
                            continue
                    textbox.press("Enter")
                    logger.info("%s: SEARCH_SUBMITTED selector=role=textbox frame=%s method=enter", self.platform, frame.url)
                    return True
            except Exception:
                pass

        for frame in frames:
            for label in ("Закупки", "Процедуры", "Поиск закупок", "Поиск процедур"):
                try:
                    loc = frame.get_by_text(label, exact=False).first
                    if loc.count() and loc.is_visible():
                        loc.click(timeout=1500)
                        page.wait_for_timeout(1200)
                        break
                except Exception:
                    continue
        for _ in range(3):
            page.wait_for_timeout(1200)
            frames = [page.main_frame] + [frame for frame in page.frames if frame != page.main_frame]
            for frame in frames:
                for selector in selectors:
                    try:
                        loc = frame.locator(selector).first
                        if loc.count() and loc.is_visible():
                            loc.fill(query)
                            loc.press("Enter")
                            logger.info("%s: SEARCH_SUBMITTED selector=%s frame=%s method=late-enter", self.platform, selector, frame.url)
                            return True
                    except Exception:
                        continue
        return False

    @staticmethod
    def _expand_results(page) -> None:
        labels = ("Загрузить еще", "Загрузить ещё", "Показать еще", "Показать ещё", "Еще", "Ещё", "Следующая", "Следующая страница", "Далее", "Next")
        stable = 0
        previous = -1
        for _ in range(20):
            try:
                current = page.locator("a[href], article, tr, li").count()
            except Exception:
                current = previous
            stable = stable + 1 if current == previous else 0
            if stable >= 3:
                break
            previous = current
            clicked = False
            for label in labels:
                try:
                    candidates = page.get_by_text(label, exact=False)
                    for index in range(candidates.count() - 1, -1, -1):
                        loc = candidates.nth(index)
                        try:
                            if not loc.is_visible():
                                continue
                            loc.click(timeout=1500)
                            page.wait_for_timeout(1500)
                            clicked = True
                            break
                        except Exception:
                            continue
                    if clicked:
                        break
                except Exception:
                    continue
            if not clicked:
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                page.wait_for_timeout(1200)


class ReliableRtsTenderCollector(ReliableBrowserSearchMixin, RtsTenderCollector):
    """RTS-Tender with resilient search widget discovery."""


class ReliableTmkCollector(ReliableBrowserSearchMixin, TmkCollector):
    """TMK procurement portal with resilient search widget discovery."""


class ReliableRosatomCollector(ReliableBrowserSearchMixin, RosatomCollector):
    """Rosatom procurement portal with resilient search widget discovery."""

    ALLOW_PUBLISHED_LISTING_FALLBACK = False

    def _perform_search(self, page, query: str) -> bool:
        # Rosatom has a dedicated filter panel; the generic SPA search mixin can
        # mistake unrelated textboxes for the procurement filter. Use the
        # platform-specific implementation and return its successful submission.
        return bool(RosatomCollector._perform_search(self, page, query))
